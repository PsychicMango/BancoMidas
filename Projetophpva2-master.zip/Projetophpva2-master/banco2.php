<?php
    include "Pagina_Acessada.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <fieldset>
        <form>
            <input type="text" name= "nome">
            <input type="number" name= "agencia">
            <input type="number" name= "bandeira">
        </form>
    </fieldset>
</body>
</html>